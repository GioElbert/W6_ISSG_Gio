const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");


const socket = io("http://localhost:3000")

const r1 = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prinot: "> "
});

let username = "";
//Deklarasi Key Signature
let privateKey;
let publicKey;

// Generate RSA key pair for signing and verification
function generateKeyPair() {
    //Ini fungsi yang digunakan untuk mendeteksi adanya error, sehingga program akan memunculkan pesan error dan code tidak menjalankannya.
    try {
        const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
            modulusLength: 2048,
            publicKeyEncoding: { type: 'spki', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
        });
        return { publicKey, privateKey };
    } catch (error) {
        console.error("Error generating key pair:", error);
    }
}

// Generate a digital signature for the message
function signMessage(message) {
    //Ini fungsi yang digunakan untuk mendeteksi adanya error, sehingga program akan memunculkan pesan error dan code tidak menjalankannya.
    try {
        const sign = crypto.createSign('SHA256');
        sign.update(message);
        sign.end();
        return sign.sign(privateKey, 'hex');
    } catch (error) {
        console.error("Error signing message:", error);
        return null;
    }
}

// Verify the digital signature of a message
function verifySignature(message, signature, publicKey) {
   // Sama Fungsi untuk deteksi error 
    try {
        const verify = crypto.createVerify('SHA256');
        verify.update(message);
        verify.end();
        return verify.verify(publicKey, signature, 'hex');
    } catch (error) {
        console.error("Error verifying signature:", error);
        return false;
    }
}

// function generateHash(message) {
//     return crypto.createHash('sha256').update(message).digest('hex');
// }

socket.on("connect", () => {
    console.log("Connected to the server");

    const keys = generateKeyPair();
    publicKey = keys.publicKey;
    privateKey = keys.privateKey;

    //Memeriksa apakah Public Key dan Private key sudah ada, kalau tidak ada, maka error
    if (!publicKey || !privateKey) {
        console.error("Failed to generate keys. Exiting...");
        process.exit(1);
    }

    r1.question("Enter your username: ", (input) => {
        username = input;
        console.log(`Welcome, ${username} to the chat`);
        r1.prompt();

        // Send messages with digital signature
        r1.on("line", (message) => {
            if (message.trim()) {
                const signature = signMessage(message);
                //Memastikan bahwa telah ada signature, jika signature tidak ada maka pesan tidak akan di kirimkan.
                if (signature) {
                    socket.emit("message", { username, message, signature, publicKey });
                } else {
                    console.error("Message signing failed. Message not sent.");
                }            }
            r1.prompt();
        });
    });
});

// Message reception with verification
socket.on("message", (data) => {
    const { username: senderUsername, message: senderMessage, signature, publicKey: senderPublicKey } = data;

    if (senderUsername !== username) {
        //Pengirim harus punya Public key
        if (!senderPublicKey) {
            console.error("No public key received. Cannot verify message.");
            return;
        }
        // Verify the digital signature
        const isVerified = verifySignature(senderMessage, signature, senderPublicKey);
        if (isVerified) {
            console.log(`${senderUsername}: ${senderMessage} (signature verified)`);
        } else {
            console.log(`${senderUsername}: ${senderMessage} (WARNING: signature invalid!)`);
        }
        r1.prompt();
    }
});

socket.on("disconnect", () => {
    console.log("Server disconnected, Exiting...");
    r1.close();
    process.exit(0);
});

r1.on("SIGINT", ()=> {
    console.log("\nExiting...");
    socket.disconnect();
    r1.close();
    process.exit(0);
});